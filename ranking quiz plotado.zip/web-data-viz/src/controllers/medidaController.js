var medidaModel = require("../models/medidaModel");

function buscarUltimasMedidas(req, res) {


    console.log(`Recuperando as ultimos times`);

    medidaModel.buscarUltimasMedidas().then(function (resultado) {
        if (resultado.length > 0) {
            res.status(200).json(resultado);
        } else {
            res.status(204).send("Nenhum resultado encontrado!")
        }
    }).catch(function (erro) {
        console.log(erro);
        console.log("Houve um erro ao buscar as ultimas medidas.", erro.sqlMessage);
        res.status(500).json(erro.sqlMessage);
    });
}

// Foi adicionada esta função com o intuito de fazer verificações, continuar o caminho e plotar o gráfico do quiz
function ultimasquiz(req, res) {
    
    const fkUsuario = req.query.idUsuario;

    console.log(`Recuperando medidas em tempo real`);

    // Aqui, após as verificações, irá para "medidaModel", onde fará o camando necessário para o comportamento do gráfico.
    medidaModel.ultimasquiz(fkUsuario).then(function (resultado) {
        if (resultado.length > 0) {
            res.status(200).json(resultado);
        } else {
            res.status(204).send("Nenhum resultado encontrado!")
        }
    }).catch(function (erro) {
        console.log(erro);
        console.log("Houve um erro ao buscar as ultimas medidas.", erro.sqlMessage);
        res.status(500).json(erro.sqlMessage);
    });
}

// foi criada essa função, para dar continuidade no caminho afim de realizar e salvar as informações do quiz.
function cadastrarresposta(req, res) {
    
    // Aqui criamos outas variáveis que irão recuperar os valores daquelas que forão criadas no "quiz.html".
    var pontuacao = req.body.pontuacaoServer;
    var fkUsuario = req.body.fkUsuarioServer;
    var porcentagem = req.body.porcentagemServer;
    var acertos = req.body.acertosServer;
    var erros = req.body.errosServer;
    
    if (pontuacao == 0) {
        res.status(400).send("Você não acertou nenhuma pergunta");
    } else {

        // Ao seguir o caminho da rota criada, chegamos aqui, em que será feito determinadas verificações e posteriormente será levado a medidaModel, na função "cadastrarresposta" para fazer o camando que irá ser salvo no banco.
        medidaModel.cadastrarresposta(pontuacao, fkUsuario, porcentagem, acertos, erros)
            .then(
                function (resultado) {
                    res.json(resultado);
                }
            ).catch(
                function (erro) {
                    console.log(erro);
                    console.log(
                        "\nHouve um erro ao realizar o cadastro! Erro: ",
                        erro.sqlMessage
                    );
                    res.status(500).json(erro.sqlMessage);
                }
            );
    }
}

// Foi criado esta função, para que, chegando da "router" fosse feita algumas atribuições e verificações.
function exibirRankingQuiz(req, res) {
    
    console.log(`Recuperando medidas em tempo real`);

    // Aqui, após as verificações, irá para "medidaModel", na função "exibirRankingQuiz" onde fará o camando necessário para o comportamento do gráfico.
    medidaModel.exibirRankingQuiz().then(function (resultado) {
        if (resultado.length > 0) {
            res.status(200).json(resultado);
        } else {
            res.status(204).send("Nenhum resultado encontrado!")
        }
    }).catch(function (erro) {
        console.log(erro);
        console.log("Houve um erro ao buscar as ultimas medidas.", erro.sqlMessage);
        res.status(500).json(erro.sqlMessage);
    });
}

module.exports = {
    buscarUltimasMedidas,
    ultimasquiz,
    cadastrarresposta,
    exibirRankingQuiz
}