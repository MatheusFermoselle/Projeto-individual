var database = require("../database/config");

function buscarUltimasMedidas() {

    // Para o comportamento dos gráficos das equipes e dos esquemas, foi criado este "select".
    var instrucaoSql = `select equipe.nome, esquema.tipo from usuario
join equipe on usuario.fkEquipe = equipe.idEquipe
join esquema on usuario.fkEsquema = esquema.idEsquema order by usuario.id;`

    console.log("Executando a instrução SQL: \n" + instrucaoSql);
    return database.executar(instrucaoSql);
}

// Foi adicionada esta função para terminar o caminho, visando plotar o gráfico quiz da maneira desejada.
function ultimasquiz(fkUsuario) {
    // Este select foi criado e testado primeiramente no banco. Com ele, mostrarei ao usuário seu percentual de acertos e erros.
    var instrucaoSql = `select porcentagem as porcentagemUsuario from quiz join usuario on ${fkUsuario} = usuario.id order by quiz.idQuiz desc limit 1; `;

    console.log("Executando a instrução SQL: \n" + instrucaoSql);
    return database.executar(instrucaoSql);
}

// Foi criada essa função, em que é responsável por finalizar o caminho e pela instruçãoSql, ou seja, literalmente o comando que irá para o banco, para salvar as informações do quiz.
function cadastrarresposta(pontuacao, fkUsuario, porcentagem, acertos, erros) {
// para finalizar todo o caminho que se iniciou na rota, fazemos o comando do insert que queremos no banco aqui.
//Como desejo salvar o usuário, sua respectiva pontuação e sua porcentagem de acerto, coloco essas variáveis na instruçãoSql.

    var instrucaoSql = `insert into quiz (pontuacao, fkUsuario, porcentagem, acertos, erros) values
(${pontuacao}, ${fkUsuario}, ${porcentagem}, ${acertos}, ${erros});`;

    console.log("Executando a instrução SQL: \n" + instrucaoSql);
    // Aqui mostra que o banco de dados irá executar o camando escrito acima.
    return database.executar(instrucaoSql);
}

// Foi criado esta função, a qual é responsável por finalizar o caminho iniciado pelo "fetch" e realizar o comando que irá mostrar aos usuários as informções desejadas.
function exibirRankingQuiz() {
    
    // 16/07: foi alterado esse "select"
    var instrucaoSql = `select usuario.nome AS Usuario, max(quiz.pontuacao) as Pontuação from usuario join quiz on usuario.id = quiz.fkUsuario group by
     usuario.nome ORDER BY Pontuação desc limit 5; `;

    console.log("Executando a instrução SQL: \n" + instrucaoSql);
    // Aqui mostra que o banco de dados irá executar o camando escrito acima.
    return database.executar(instrucaoSql);
}

// 17/07: Foi criado esta função, 
//a qual é responsável por finalizar o caminho iniciado pelo "fetch" e realizar o comando que irá mostrar aos usuários as informções desejadas.
function exibirRankingQuiz2() {
    
    // 17/07: foi criado esse "select"
    var instrucaoSql = `select usuario.nome as Usuario, min(quiz.pontuacao) as MinPontuação from usuario join quiz on fkUsuario = usuario.id group by 
    Usuario order by MinPontuação limit 5; `;

    console.log("Executando a instrução SQL: \n" + instrucaoSql);
    // Aqui mostra que o banco de dados irá executar o camando escrito acima.
    return database.executar(instrucaoSql);
}

module.exports = {
    buscarUltimasMedidas,
    ultimasquiz,
    cadastrarresposta,
    exibirRankingQuiz,
    exibirRankingQuiz2
}
