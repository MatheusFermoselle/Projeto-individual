var express = require("express");
var router = express.Router();

var medidaController = require("../controllers/medidaController");

router.get("/ultimas/", function (req, res) {
    medidaController.buscarUltimasMedidas(req, res);
});


// Rota alterada. Aqui foi iniciado o caminho para plotar o gráfico do quiz.
router.get("/ultimas-quiz/", function (req, res) {
    // Essa rota, leva para a função "ultimasquiz" em "medidaController.js"
    medidaController.ultimasquiz(req, res);
})

// Chegando do quiz.html, através do "fetch", essa outra rota criada, chamada "cadastrarresposta" é o caminho para fazer o "post", ou seja, salvar no banco de dados as informações do quiz. Este caminho leva para a função chamada "cadastrarresposta" da medidaController.
router.post("/cadastrarresposta", function (req, res) {
    // Essa rota, leva para a função "cadastrarresposta" em "medidaController.js"
    medidaController.cadastrarresposta(req, res);
})

// Chegando da Dashboard.html, através do "fetch", essa outra rota criada, chamada "exibirRankingQuiz" é o caminho para fazer o "get", ou seja, pegar do banco de dados as informações do ranking quiz. Este caminho leva para a função chamada "exibirRankingQuiz" da medidaController.
router.get("/exibirRankingQuiz", function (req, res) {
    // Essa rota, leva para a função "exibirRankingQuiz" em "medidaController.js"
    medidaController.exibirRankingQuiz(req, res);
})

// 17/07: Chegando da Dashboard.html, através do "fetch", essa outra rota criada,
// chamada "exibirRankingQuiz2" é o caminho para fazer o "get", ou seja, pegar do banco de dados as informações do ranking quiz. 
//Este caminho leva para a função chamada "exibirRankingQuiz2" da medidaController.
router.get("/exibirRankingQuiz2", function (req, res) {
    // Essa rota, leva para a função "exibirRankingQuiz2" em "medidaController.js"
    medidaController.exibirRankingQuiz2(req, res);
})

module.exports = router;